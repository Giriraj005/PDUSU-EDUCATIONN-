# PDSU Digital Library - Quick Start Guide

## 🚀 5-Minute Setup

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Configure Firebase (Already Done!)
Your Firebase config is already in the code. Skip this step.

### Step 3: Deploy Firestore Security Rules

**CRITICAL - DO THIS FIRST!**

1. Go to: https://console.firebase.google.com/project/giriraj-pareek/firestore
2. Click "Rules" tab
3. Copy contents from `firestore.rules` file
4. Paste into the editor
5. Click "Publish"

### Step 4: Enable Authentication

1. Go to: https://console.firebase.google.com/project/giriraj-pareek/authentication
2. Click "Get started"
3. Enable "Email/Password" provider
4. Click "Save"

### Step 5: Run Development Server
```bash
npm run dev
```

Visit: http://localhost:5173

### Step 6: Create Admin Account

1. Click "Register"
2. Use email: `admin@pdsu.ac.in`
3. Create a password
4. You're now admin!

---

## ✅ You're Ready!

Now you can:
- Upload books in Admin Panel
- Test the purchase flow
- Share with students

---

## 📦 Project Structure

```
pdsu-digital-library/
├── src/
│   ├── App.jsx              # Main application (your code)
│   ├── main.jsx             # Entry point
│   └── index.css            # Tailwind styles
├── public/
│   └── index.html
├── package.json             # Dependencies
├── firestore.rules          # Database security rules
├── vite.config.js           # Build config
└── DEPLOYMENT_GUIDE.md      # Full deployment docs
```

---

## 🌐 Deploy to Production

### Option A: Firebase Hosting (Free)

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Initialize
firebase init hosting

# Build
npm run build

# Deploy
firebase deploy --only hosting
```

Your site: `https://giriraj-pareek.web.app`

### Option B: Vercel (Free & Fast)

1. Push code to GitHub
2. Import to Vercel
3. Deploy automatically

---

## 🧪 Testing Checklist

- [ ] Register a test student account
- [ ] Login as student
- [ ] Browse library
- [ ] Try to purchase a book (use real UPI or test)
- [ ] Check "My Books" shows pending status
- [ ] Login as admin
- [ ] See pending payment
- [ ] Approve it
- [ ] Login back as student
- [ ] Verify book is now accessible
- [ ] Test the secure viewer (no right-click, etc.)

---

## 💰 Payment Testing

### Test UTR Numbers (for development):
Use any 12-digit number: `123456789012`

### Real Testing:
1. Pay ₹1 to your UPI ID
2. Note the UTR number
3. Submit and verify admin can approve

---

## 🆘 Common Issues

### Issue: "Permission denied" on Firestore
**Fix:** Deploy security rules (Step 3 above)

### Issue: "Admin panel not showing"
**Fix:** Make sure you registered with exactly `admin@pdsu.ac.in`

### Issue: "QR code not working"
**Fix:** Verify UPI ID in code: `7727867614@postbank`

### Issue: Build errors
**Fix:** Run `npm install` again

---

## 📱 Mobile Testing

Test on actual phones:
1. Deploy to Firebase Hosting or Vercel
2. Share link with friends
3. Test QR code scanning
4. Test payment flow
5. Check responsive design

---

## 🎯 Next Steps

1. **Add real content** - Upload 5-10 important question PDFs
2. **Test thoroughly** - Complete purchase flow end-to-end
3. **Share with beta testers** - Get feedback from 10 students
4. **Monitor Firebase** - Check usage in console
5. **Launch officially** - Share link on WhatsApp/college groups

---

## 📊 Admin Dashboard Features

Your admin panel can:
- View all pending payments (with UTR numbers)
- Approve/reject purchases with one click
- Upload new books with HTML content
- See all books in library

Future additions:
- Revenue analytics
- Popular books stats
- Active user count
- Download reports

---

## 🔐 Security Features Active

✅ Firebase Authentication
✅ Firestore Security Rules
✅ No right-click on books
✅ No screenshot shortcuts
✅ Text selection disabled
✅ Email watermarking
✅ Access control per user
✅ Manual payment verification

---

## 💡 Pro Tips

1. **Start small** - Begin with 5-10 books
2. **Price reasonably** - ₹29-99 per book is good
3. **Fast approval** - Approve payments within 1-2 hours
4. **Clear communication** - Tell students verification time
5. **Test everything** - Don't skip the testing checklist
6. **Monitor daily** - Check Firebase console for errors
7. **Backup data** - Export Firestore data regularly

---

## 📞 Support

- Firebase Console: https://console.firebase.google.com/project/giriraj-pareek
- Firebase Docs: https://firebase.google.com/docs
- React Docs: https://react.dev

---

## 🎉 You're All Set!

Your platform is production-ready. Just follow the steps above and you'll be live in 30 minutes!

**Remember:** Deploy Firestore rules FIRST before anything else!
