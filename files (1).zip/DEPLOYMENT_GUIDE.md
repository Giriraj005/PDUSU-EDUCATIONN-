# PDSU Digital Library - Deployment Guide

## 🚀 What You've Built

A complete production-ready e-learning platform with:
- Firebase Authentication for user management
- Firestore Database for books and purchases
- Real UPI payment verification system
- Admin panel for manual verification
- Security features (no downloads/screenshots)

---

## 📋 Pre-Deployment Checklist

### 1. **Firebase Console Setup**

Go to: https://console.firebase.google.com/project/giriraj-pareek

#### A. **Firestore Security Rules** (CRITICAL!)

Navigate to: **Firestore Database → Rules**

Replace the default rules with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Books collection - Read by all authenticated users, Write only by admins
    match /books/{bookId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.token.email == 'admin@pdsu.ac.in';
    }
    
    // Purchases collection - Users can read their own, admins can read/write all
    match /purchases/{purchaseId} {
      allow read: if request.auth != null && 
                     (resource.data.userId == request.auth.uid || 
                      request.auth.token.email == 'admin@pdsu.ac.in');
      allow create: if request.auth != null && request.resource.data.userId == request.auth.uid;
      allow update: if request.auth != null && request.auth.token.email == 'admin@pdsu.ac.in';
    }
  }
}
```

**Deploy these rules immediately!** Without them, anyone can read/write your database.

#### B. **Authentication Setup**

Navigate to: **Authentication → Sign-in method**

1. Enable **Email/Password** authentication
2. (Optional) Enable **Google** sign-in for easier registration

#### C. **Storage (for future PDF uploads)**

Navigate to: **Storage → Rules**

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /books/{allPaths=**} {
      // Only admins can upload
      allow write: if request.auth != null && request.auth.token.email == 'admin@pdsu.ac.in';
      // Authenticated users can read (we'll implement book-level access in app logic)
      allow read: if request.auth != null;
    }
  }
}
```

---

## 🔐 Security Improvements

### 1. **Create Admin Account**

First, register at your app with `admin@pdsu.ac.in` email to create the admin account.

### 2. **Better Admin Management** (Recommended)

Create a Firestore collection called `admins`:

```javascript
// In Firebase Console → Firestore → Add Collection
Collection: admins
Document ID: admin@pdsu.ac.in
Fields:
  - role: "admin"
  - name: "Your Name"
  - addedOn: [Timestamp]
```

Then update your code's admin check:

```javascript
// Instead of hardcoded email
const [adminEmails, setAdminEmails] = useState([]);

useEffect(() => {
  const fetchAdmins = async () => {
    const snapshot = await getDocs(collection(db, "admins"));
    setAdminEmails(snapshot.docs.map(d => d.id));
  };
  fetchAdmins();
}, []);

// Then check:
const isAdmin = adminEmails.includes(user.email);
```

### 3. **Environment Variables** (For Production)

Move Firebase config to environment variables:

```javascript
// .env file
REACT_APP_FIREBASE_API_KEY=AIzaSyBHFVlEkyAFLuMuYsbdBuHpr0OjyWmVQK4
REACT_APP_FIREBASE_AUTH_DOMAIN=giriraj-pareek.firebaseapp.com
REACT_APP_FIREBASE_PROJECT_ID=giriraj-pareek
# ... etc

// In code:
const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  // ... etc
};
```

**Note:** Firebase config in frontend is safe to expose (it's public by design). Database security comes from Firestore Rules.

---

## 🌐 Deployment Options

### Option 1: **Firebase Hosting** (Recommended - Free Tier Available)

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Initialize in your project
firebase init hosting

# Build your React app
npm run build

# Deploy
firebase deploy --only hosting
```

**Your app will be live at:** `https://giriraj-pareek.web.app`

### Option 2: **Vercel** (Free, Fast)

1. Push your code to GitHub
2. Visit: https://vercel.com
3. Import your GitHub repository
4. Vercel auto-detects React and deploys
5. Live in 2 minutes!

### Option 3: **Netlify** (Free)

1. Push to GitHub
2. Visit: https://netlify.com
3. Connect repository
4. Deploy automatically

### Option 4: **Your Own Server** (Traditional)

```bash
# Build the app
npm run build

# Upload the 'build' folder to your server
# Serve with nginx/apache
```

---

## 💳 Payment Verification Workflow

### Current Flow:
1. Student scans QR code → Pays via UPI
2. Student enters 12-digit UTR number
3. Purchase saved with `status: 'pending'`
4. Admin sees pending payment in dashboard
5. Admin manually verifies UTR in bank account
6. Admin clicks "Approve" → `status: 'approved'`
7. Student can now access the book

### How to Verify UTR:

1. **Login to your bank** (IPPB in your case)
2. **Check transaction history**
3. **Match the UTR number** with amount and date
4. **Verify in admin panel**

### Future: Auto-Verification Options

For automatic verification, integrate:

**Option A: Razorpay Payment Gateway**
- Instant verification
- Auto-approve on success
- ₹2 per transaction (~3% fee)

**Option B: UPI Collect API**
- Bank integration required
- More complex setup

**Option C: Cashfree/PayU**
- Similar to Razorpay
- Good for India market

---

## 📚 PDF Upload & Storage

### Current: HTML Content Storage
Books stored as HTML in `content` field.

### Future: Real PDF Upload

**Step 1:** Install Firebase Storage

```bash
npm install firebase
```

**Step 2:** Update Upload Form

```javascript
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

const storage = getStorage(app);

async function uploadPDF(file) {
  const storageRef = ref(storage, `books/${Date.now()}_${file.name}`);
  await uploadBytes(storageRef, file);
  const url = await getDownloadURL(storageRef);
  return url;
}

// In your upload form:
<input type="file" accept=".pdf" onChange={async (e) => {
  const file = e.target.files[0];
  const url = await uploadPDF(file);
  setData({...data, content: url, contentType: 'pdf'});
}} />
```

**Step 3:** Display PDF Securely

Use PDF.js for secure viewing:

```bash
npm install react-pdf
```

```javascript
import { Document, Page } from 'react-pdf';

<Document file={book.content}>
  <Page pageNumber={1} />
</Document>
```

---

## 🛡️ Enhanced Security Features

### 1. **Email Verification**

Add to registration:

```javascript
import { sendEmailVerification } from "firebase/auth";

const reg = async (ev) => {
  ev.preventDefault();
  const userCredential = await createUserWithEmailAndPassword(auth, form.email, form.pass);
  await sendEmailVerification(userCredential.user);
  alert("Verification email sent! Please check your inbox.");
};
```

### 2. **Password Reset**

```javascript
import { sendPasswordResetEmail } from "firebase/auth";

const resetPassword = async (email) => {
  await sendPasswordResetEmail(auth, email);
  alert("Reset link sent to your email!");
};
```

### 3. **Anti-Screenshot Watermark**

Add dynamic watermark in BookViewer:

```javascript
<div className="fixed inset-0 pointer-events-none z-50 opacity-20">
  <div className="grid grid-cols-3 grid-rows-4 h-full">
    {[...Array(12)].map((_, i) => (
      <div key={i} className="flex items-center justify-center text-gray-900 text-2xl font-bold transform -rotate-45">
        {currentUser.email}
      </div>
    ))}
  </div>
</div>
```

### 4. **Activity Logging**

Track who views what:

```javascript
// When book is opened
await addDoc(collection(db, "activity_logs"), {
  userId: currentUser.uid,
  userEmail: currentUser.email,
  bookId: book.id,
  action: 'view',
  timestamp: new Date(),
  ipAddress: await fetch('https://api.ipify.org?format=json').then(r => r.json()).then(d => d.ip)
});
```

---

## 📊 Admin Analytics Dashboard (Future Feature)

Add to Admin Panel:

```javascript
// Total revenue
const totalRevenue = purchases
  .filter(p => p.status === 'approved')
  .reduce((sum, p) => sum + p.amount, 0);

// Most popular books
const bookSales = {};
purchases.forEach(p => {
  if (p.status === 'approved') {
    bookSales[p.bookId] = (bookSales[p.bookId] || 0) + 1;
  }
});

// Active users count
const activeUsers = [...new Set(purchases.map(p => p.userId))].length;
```

---

## ⚠️ Important Notes

### 1. **Firebase Free Tier Limits**

- **Authentication:** 10K verifications/month (sufficient for 1000+ students)
- **Firestore:** 50K reads, 20K writes/day (enough for 100+ active students daily)
- **Storage:** 5GB total (good for ~500 PDFs)
- **Hosting:** 10GB bandwidth/month

**Monitor usage:** https://console.firebase.google.com/project/giriraj-pareek/usage

### 2. **Scaling Up**

When you grow beyond free tier:
- **Blaze Plan (Pay-as-you-go):** Very cheap for small apps
- **Expected cost for 1000 students:** ₹500-1500/month

### 3. **Legal Considerations**

Create these documents:
1. **Terms of Service** (no content sharing, copyright protection)
2. **Privacy Policy** (data collection, usage)
3. **Refund Policy** (verification failures, disputes)

### 4. **Customer Support**

Add a support email to the footer:
```javascript
<p>Support: support@pdsubooks.com</p>
```

---

## 🐛 Troubleshooting

### "Permission Denied" errors
→ Check Firestore rules are deployed

### "No such document" errors
→ Ensure collections exist in Firestore

### Users can't register
→ Check Email/Password is enabled in Firebase Console

### QR code not working
→ Test UPI ID: Try `upi://pay?pa=7727867614@postbank&pn=Test&am=1&cu=INR`

### Admin can't approve payments
→ Ensure admin email matches exactly in code

---

## 📞 Support & Updates

**Your Firebase Project:** https://console.firebase.google.com/project/giriraj-pareek

**Need help?** Check:
- Firebase Docs: https://firebase.google.com/docs
- React Docs: https://react.dev
- Stack Overflow (tag: firebase)

---

## ✅ Launch Checklist

Before going live:

- [ ] Deploy Firestore security rules
- [ ] Enable Email/Password authentication
- [ ] Create admin account (admin@pdsu.ac.in)
- [ ] Upload 2-3 test books
- [ ] Test full purchase flow with real UPI payment
- [ ] Test admin approval process
- [ ] Add Terms of Service page
- [ ] Test on mobile devices
- [ ] Share link with 5 beta testers
- [ ] Monitor Firebase usage dashboard

---

**🎉 You're ready to launch!**

Your platform is production-ready. Just deploy Firestore rules and you're good to go!
