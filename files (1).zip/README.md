# 📚 PDSU Digital Library

> E-Learning Platform for Pandit Deendayal Upadhyaya Shekhawati University Students

A complete, production-ready platform for selling and delivering educational content (PDFs, study materials, important questions) with real payment verification via UPI.

![Firebase](https://img.shields.io/badge/Firebase-FFCA28?style=for-the-badge&logo=firebase&logoColor=black)
![React](https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=react&logoColor=black)
![Tailwind](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)

---

## ✨ Features

### 🔐 **Authentication & Security**
- Firebase Authentication (Email/Password)
- Secure user registration and login
- Role-based access (Student/Admin)
- Protected content viewing
- Anti-screenshot measures
- Email watermarking

### 💳 **Payment System**
- UPI QR Code generation
- UTR number verification
- Manual admin approval
- Purchase history tracking
- Pending/Approved status

### 📖 **Content Management**
- Upload books via Admin Panel
- HTML content support
- PDF URL support (can extend to actual PDF upload)
- Category organization
- Subject-wise filtering
- Search functionality

### 🛡️ **Security Features**
- Right-click disabled on books
- Screenshot prevention (keyboard shortcuts blocked)
- Text selection disabled
- User-specific watermarks
- Firestore Security Rules
- Access control per user

---

## 🚀 Quick Start

### 1️⃣ Install Dependencies
```bash
npm install
```

### 2️⃣ Deploy Firestore Rules (CRITICAL!)

Go to [Firebase Console → Firestore → Rules](https://console.firebase.google.com/project/giriraj-pareek/firestore/rules)

Copy contents from `firestore.rules` and publish.

### 3️⃣ Enable Authentication

Go to [Firebase Console → Authentication](https://console.firebase.google.com/project/giriraj-pareek/authentication)

Enable "Email/Password" provider.

### 4️⃣ Run Development Server
```bash
npm run dev
```

Visit: **http://localhost:5173**

### 5️⃣ Create Admin Account

Register with email: `admin@pdsu.ac.in`

---

## 📁 Project Structure

```
pdsu-digital-library/
├── src/
│   ├── App.jsx                    # Main React application
│   ├── main.jsx                   # Entry point
│   └── index.css                  # Tailwind + custom styles
├── public/
│   └── index.html                 # HTML template
├── package.json                   # Dependencies
├── firestore.rules                # Database security
├── vite.config.js                 # Build configuration
├── tailwind.config.js             # Tailwind config
├── DEPLOYMENT_GUIDE.md            # Full deployment docs
├── QUICK_START.md                 # Quick setup guide
└── README.md                      # This file
```

---

## 🎯 User Journey

### **For Students:**

1. **Register** → Enter name, email, password
2. **Browse Library** → See all available books
3. **Purchase Book** → Scan QR → Pay via UPI → Enter UTR
4. **Wait for Verification** → Admin approves (1-2 hours)
5. **Access Content** → Read in secure viewer
6. **My Books** → All purchased content

### **For Admin:**

1. **Login** with admin@pdsu.ac.in
2. **View Payments** → See pending UTR verifications
3. **Verify** → Check bank account
4. **Approve** → One-click approval
5. **Upload Books** → Add new content
6. **Manage Library** → Track all books

---

## 🛠️ Technology Stack

| Technology | Purpose |
|------------|---------|
| **React 18** | Frontend framework |
| **Firebase Auth** | User authentication |
| **Firestore** | Database (books, purchases) |
| **Tailwind CSS** | Styling |
| **Vite** | Build tool |
| **Lucide React** | Icons |

---

## 💰 Payment Flow

```
Student scans QR Code
    ↓
Pays via UPI App
    ↓
Gets 12-digit UTR Number
    ↓
Enters UTR in platform
    ↓
Purchase saved as "pending"
    ↓
Admin sees in dashboard
    ↓
Admin checks bank account
    ↓
Admin clicks "Approve"
    ↓
Status changes to "approved"
    ↓
Student can access book
```

---

## 🔧 Configuration

### Firebase Config (Already Set)

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyBHFVlEkyAFLuMuYsbdBuHpr0OjyWmVQK4",
  authDomain: "giriraj-pareek.firebaseapp.com",
  projectId: "giriraj-pareek",
  // ... etc
};
```

### Admin Email (Change if needed)

In `src/App.jsx`:
```javascript
const isAdmin = user.email === 'admin@pdsu.ac.in'; // Change this
```

### UPI ID (Your payment receiver)

In `src/App.jsx` → `PaymentModal`:
```javascript
const upiId = "7727867614@postbank"; // Change this
```

---

## 📦 Deployment

### Option 1: Firebase Hosting (Recommended)

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy --only hosting
```

**Live at:** `https://giriraj-pareek.web.app`

### Option 2: Vercel

1. Push to GitHub
2. Import to Vercel
3. Auto-deploy

### Option 3: Netlify

Same as Vercel - connect GitHub and deploy.

---

## 🧪 Testing Checklist

- [ ] Register student account
- [ ] Login as student
- [ ] Browse library
- [ ] Try purchase (use real UPI)
- [ ] Enter UTR number
- [ ] Check "My Books" shows pending
- [ ] Login as admin
- [ ] See pending payment with UTR
- [ ] Approve payment
- [ ] Login back as student
- [ ] Verify book is accessible
- [ ] Test secure viewer (no right-click)
- [ ] Test on mobile device

---

## 🔐 Security Best Practices

### Already Implemented:
✅ Firebase Authentication
✅ Firestore Security Rules
✅ No downloads/screenshots
✅ Text selection disabled
✅ Right-click disabled
✅ Email watermarking
✅ User-specific access control

### Recommended Additions:
- [ ] Email verification on signup
- [ ] Password reset functionality
- [ ] Rate limiting for payments
- [ ] Activity logging
- [ ] Backup database regularly
- [ ] Terms of Service page
- [ ] Privacy Policy page

---

## 📊 Firebase Free Tier Limits

| Resource | Free Limit | Sufficient For |
|----------|-----------|----------------|
| **Auth** | 10K/month | 1000+ students |
| **Firestore Reads** | 50K/day | 100+ students/day |
| **Firestore Writes** | 20K/day | 50+ purchases/day |
| **Storage** | 5GB | 500+ PDFs |
| **Hosting** | 10GB/month | High traffic |

**Scaling:** Upgrade to Blaze plan when needed (~₹500-1500/month for 1000 students)

---

## 🆘 Troubleshooting

### Issue: "Permission denied" errors
**Fix:** Deploy Firestore security rules from `firestore.rules`

### Issue: Can't login as admin
**Fix:** Register with exactly `admin@pdsu.ac.in`

### Issue: QR code not working
**Fix:** Test UPI ID in any UPI app first

### Issue: Books not showing
**Fix:** Upload books from Admin Panel

### Issue: Payment not appearing
**Fix:** Check Firestore console for `purchases` collection

---

## 🎓 Educational Use

This platform is designed for:
- Important questions for exams
- Previous year papers
- Study notes and materials
- Subject-wise content
- Semester-wise organization

**Target Users:** College and university students

---

## 📞 Support

- **Firebase Console:** [console.firebase.google.com](https://console.firebase.google.com/project/giriraj-pareek)
- **Firebase Docs:** [firebase.google.com/docs](https://firebase.google.com/docs)
- **React Docs:** [react.dev](https://react.dev)

---

## 📄 License

MIT License - Feel free to use and modify.

---

## 👨‍💻 Developer

**Giriraj Pareek**
- UPI: 7727867614@postbank (India Post Payments Bank)
- Project: PDSU Digital Library

---

## 🎉 Ready to Launch!

Your platform is **production-ready**. Just:

1. Deploy Firestore rules
2. Enable authentication
3. Create admin account
4. Upload books
5. Share with students!

**Need help?** Check `DEPLOYMENT_GUIDE.md` for detailed instructions.

---

## 🔄 Version History

**v1.0.0** (Current)
- Firebase integration
- UPI payment verification
- Admin approval system
- Secure content viewer
- Mobile responsive design

---

## 🚧 Future Enhancements

- [ ] Automatic payment verification via Payment Gateway
- [ ] Email notifications
- [ ] Revenue analytics dashboard
- [ ] Bulk book upload
- [ ] PDF storage in Firebase Storage
- [ ] Mobile app (React Native)
- [ ] Referral system
- [ ] Discount codes
- [ ] WhatsApp integration

---

**⭐ Star this project if you find it useful!**
