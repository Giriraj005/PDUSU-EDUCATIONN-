import React, { useState, useEffect } from 'react';
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore, collection, addDoc, getDocs, query, where, updateDoc, doc, orderBy } from "firebase/firestore";
import { BookOpen, Lock, ShoppingCart, Upload, LogIn, LogOut, User, Eye, EyeOff, CheckCircle, AlertCircle, FileText, Shield, Trash2 } from 'lucide-react';

// --- YOUR FIREBASE CONFIG ---
const firebaseConfig = {
  apiKey: "AIzaSyBHFVlEkyAFLuMuYsbdBuHpr0OjyWmVQK4",
  authDomain: "giriraj-pareek.firebaseapp.com",
  projectId: "giriraj-pareek",
  storageBucket: "giriraj-pareek.firebasestorage.app",
  messagingSenderId: "364401883193",
  appId: "1:364401883193:web:4c8f03ca3e5ceb31c235e8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export default function PDSUDigitalLibrary() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentView, setCurrentView] = useState('home');
  const [books, setBooks] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [loading, setLoading] = useState(true);

  // Auth & Data Sync
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const isAdmin = user.email === 'admin@pdsu.ac.in'; // SET YOUR ADMIN EMAIL HERE
        setCurrentUser({ uid: user.uid, email: user.email, isAdmin, name: user.displayName || 'Student' });
        fetchPurchases(user.uid);
      } else {
        setCurrentUser(null);
        setPurchases([]);
      }
      fetchBooks();
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const fetchBooks = async () => {
    const querySnapshot = await getDocs(collection(db, "books"));
    setBooks(querySnapshot.docs.map(d => ({ id: d.id, ...d.data() })));
  };

  const fetchPurchases = async (uid) => {
    const q = query(collection(db, "purchases"), where("userId", "==", uid));
    const querySnapshot = await getDocs(q);
    setPurchases(querySnapshot.docs.map(d => ({ id: d.id, ...d.data() })));
  };

  if (loading) return <div className="h-screen flex items-center justify-center bg-orange-50 text-orange-600 font-bold">Loading PDSU Library...</div>;

  return (
    <div className="min-h-screen bg-orange-50 font-sans text-gray-900">
      <Header currentUser={currentUser} setCurrentView={setCurrentView} logout={() => signOut(auth)} />
      
      <main className="container mx-auto px-4 py-8">
        {currentView === 'home' && <HomePage setCurrentView={setCurrentView} currentUser={currentUser} />}
        {currentView === 'login' && <LoginPage setCurrentView={setCurrentView} />}
        {currentView === 'register' && <RegisterPage setCurrentView={setCurrentView} />}
        {currentView === 'library' && <LibraryPage books={books} currentUser={currentUser} purchases={purchases} setCurrentView={setCurrentView} refreshPurchases={fetchPurchases} />}
        {currentView === 'my-books' && <MyBooksPage books={books} currentUser={currentUser} purchases={purchases} setCurrentView={setCurrentView} />}
        {currentView === 'admin' && currentUser?.isAdmin && <AdminPanel books={books} refreshBooks={fetchBooks} />}
        {currentView.startsWith('view-') && <BookViewer bookId={currentView.split('-')[1]} books={books} currentUser={currentUser} purchases={purchases} setCurrentView={setCurrentView} />}
      </main>

      <footer className="text-center py-10 text-gray-400 text-sm">© 2024 PDSU Digital Library | Security Powered by Firebase</footer>
    </div>
  );
}

// --- SUB-COMPONENTS ---

function Header({ currentUser, setCurrentView, logout }) {
  return (
    <header className="bg-gradient-to-r from-orange-700 to-red-800 text-white shadow-xl p-4 sticky top-0 z-40">
      <div className="container mx-auto flex justify-between items-center">
        <div className="cursor-pointer" onClick={() => setCurrentView('home')}>
          <h1 className="text-xl font-black tracking-tighter">PDSU LIBRARY</h1>
          <p className="text-[10px] opacity-80 uppercase font-bold">Shekhawati University</p>
        </div>
        <nav className="flex gap-3 items-center">
          {currentUser ? (
            <>
              <button onClick={() => setCurrentView('library')} className="text-xs font-bold uppercase hover:underline">Library</button>
              <button onClick={() => setCurrentView('my-books')} className="text-xs font-bold uppercase hover:underline">My Books</button>
              {currentUser.isAdmin && (
                <button onClick={() => setCurrentView('admin')} className="bg-white text-red-700 px-3 py-1 rounded-full text-xs font-bold shadow-lg">ADMIN</button>
              )}
              <button onClick={logout} className="bg-red-600 p-2 rounded-lg hover:bg-red-700"><LogOut size={16} /></button>
            </>
          ) : (
            <button onClick={() => setCurrentView('login')} className="bg-white text-orange-700 px-6 py-2 rounded-xl font-bold">Login</button>
          )}
        </nav>
      </div>
    </header>
  );
}

function LibraryPage({ books, currentUser, purchases, setCurrentView, refreshPurchases }) {
  const [selectedBook, setSelectedBook] = useState(null);

  const getStatus = (bookId) => {
    const p = purchases.find(p => p.bookId === bookId);
    return p ? p.status : null; // 'pending' or 'approved'
  };

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {books.map(book => {
        const status = getStatus(book.id);
        return (
          <div key={book.id} className="bg-white p-6 rounded-2xl shadow-lg border-2 border-orange-100 hover:border-orange-400 transition-all">
            <div className="bg-orange-50 h-40 rounded-xl mb-4 flex items-center justify-center text-orange-200"><FileText size={64} /></div>
            <h3 className="text-xl font-bold text-gray-800 mb-1">{book.title}</h3>
            <p className="text-sm text-gray-500 mb-4">{book.subject} • {book.category}</p>
            <div className="flex justify-between items-center mb-6">
              <span className="text-2xl font-black text-orange-600">₹{book.price}</span>
              {status === 'approved' && <span className="text-green-600 font-bold text-sm flex items-center gap-1"><CheckCircle size={16}/> Owned</span>}
              {status === 'pending' && <span className="text-orange-500 font-bold text-sm">Verifying...</span>}
            </div>

            {status === 'approved' ? (
              <button onClick={() => setCurrentView(`view-${book.id}`)} className="w-full bg-green-600 text-white py-3 rounded-xl font-bold">Open Book</button>
            ) : status === 'pending' ? (
              <button disabled className="w-full bg-gray-100 text-gray-400 py-3 rounded-xl font-bold">Payment Processing</button>
            ) : (
              <button onClick={() => setSelectedBook(book)} className="w-full bg-orange-600 text-white py-3 rounded-xl font-bold hover:bg-orange-700 shadow-lg shadow-orange-200">Get it Now</button>
            )}
          </div>
        );
      })}
      {selectedBook && <PaymentModal book={selectedBook} currentUser={currentUser} onClose={() => setSelectedBook(null)} refreshPurchases={refreshPurchases} />}
    </div>
  );
}

function PaymentModal({ book, currentUser, onClose, refreshPurchases }) {
  const [utr, setUtr] = useState('');
  const [loading, setLoading] = useState(false);
  const upiId = "7727867614@postbank";

  const handlePay = async () => {
    if (utr.length < 12) return alert("Please enter correct 12-digit UTR No.");
    setLoading(true);
    try {
      await addDoc(collection(db, "purchases"), {
        userId: currentUser.uid,
        userEmail: currentUser.email,
        bookId: book.id,
        bookTitle: book.title,
        amount: book.price,
        utrNumber: utr,
        status: 'pending',
        createdAt: new Date()
      });
      alert("Verification Request Sent! Admin will verify in 1-2 hours.");
      refreshPurchases(currentUser.uid);
      onClose();
    } catch (e) { alert("Error! Try again."); }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center">
        <h3 className="text-xl font-black mb-4">SECURE PAYMENT</h3>
        <div className="bg-gray-100 p-4 rounded-2xl mb-4 inline-block">
          <img src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=${upiId}%26pn=GIRIRAJ%20PAREEK%26am=${book.price}%26cu=INR`} alt="QR" />
        </div>
        <p className="text-xs text-gray-400 mb-6 uppercase font-bold tracking-widest">GIRIRAJ PAREEK • IPPB</p>
        <div className="text-left mb-6">
          <label className="text-[10px] font-bold text-gray-400 ml-1 uppercase">UTR Number (12 Digits)</label>
          <input maxLength="12" type="text" value={utr} onChange={e => setUtr(e.target.value.replace(/\D/g,''))} className="w-full p-4 bg-orange-50 border-2 border-orange-100 rounded-xl font-mono text-center text-lg outline-none focus:border-orange-500" placeholder="0000 0000 0000" />
        </div>
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 font-bold text-gray-400">Back</button>
          <button onClick={handlePay} disabled={utr.length < 12 || loading} className="flex-1 bg-orange-600 text-white py-4 rounded-2xl font-bold shadow-xl disabled:bg-gray-300 uppercase text-xs">Verify Payment</button>
        </div>
      </div>
    </div>
  );
}

function AdminPanel({ books, refreshBooks }) {
  const [payments, setPayments] = useState([]);
  const [view, setView] = useState('p'); // 'p' for payments, 'u' for upload

  useEffect(() => {
    const load = async () => {
      const q = query(collection(db, "purchases"), where("status", "==", "pending"));
      const snap = await getDocs(q);
      setPayments(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    };
    load();
  }, []);

  const approve = async (id) => {
    await updateDoc(doc(db, "purchases", id), { status: 'approved' });
    setPayments(payments.filter(p => p.id !== id));
    alert("Approved!");
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex gap-4 mb-8">
        <button onClick={() => setView('p')} className={`flex-1 py-3 rounded-xl font-bold ${view === 'p' ? 'bg-orange-600 text-white' : 'bg-white'}`}>Payments ({payments.length})</button>
        <button onClick={() => setView('u')} className={`flex-1 py-3 rounded-xl font-bold ${view === 'u' ? 'bg-orange-600 text-white' : 'bg-white'}`}>Upload Book</button>
      </div>

      {view === 'p' ? (
        <div className="space-y-4">
          {payments.map(p => (
            <div key={p.id} className="bg-white p-6 rounded-2xl flex justify-between items-center shadow-md">
              <div>
                <p className="text-xs text-gray-400 font-bold uppercase">{p.userEmail}</p>
                <p className="font-bold text-lg">{p.bookTitle}</p>
                <p className="font-mono text-blue-600 font-bold">UTR: {p.utrNumber}</p>
              </div>
              <button onClick={() => approve(p.id)} className="bg-green-600 text-white px-6 py-2 rounded-lg font-bold">Approve</button>
            </div>
          ))}
        </div>
      ) : (
        <UploadForm refresh={refreshBooks} />
      )}
    </div>
  );
}

// --- HELPER COMPONENTS ---

function UploadForm({ refresh }) {
  const [data, setData] = useState({ title: '', subject: '', price: '', content: '', category: 'Important Questions' });
  const save = async (e) => {
    e.preventDefault();
    await addDoc(collection(db, "books"), data);
    alert("Book Uploaded!");
    setData({ title: '', subject: '', price: '', content: '', category: 'Important Questions' });
    refresh();
  };
  return (
    <form onSubmit={save} className="bg-white p-8 rounded-3xl shadow-xl grid gap-4">
      <input placeholder="Book Title" className="p-4 border rounded-xl" value={data.title} onChange={e => setData({...data, title: e.target.value})} required />
      <input placeholder="Subject" className="p-4 border rounded-xl" value={data.subject} onChange={e => setData({...data, subject: e.target.value})} required />
      <input type="number" placeholder="Price (₹)" className="p-4 border rounded-xl" value={data.price} onChange={e => setData({...data, price: e.target.value})} required />
      <textarea placeholder="HTML Content or PDF Link" className="p-4 border rounded-xl h-40" value={data.content} onChange={e => setData({...data, content: e.target.value})} required />
      <button className="bg-orange-600 text-white py-4 rounded-xl font-bold">Save Book</button>
    </form>
  );
}

function LoginPage({ setCurrentView }) {
  const [e, setE] = useState('');
  const [p, setP] = useState('');
  const login = async (ev) => {
    ev.preventDefault();
    try { await signInWithEmailAndPassword(auth, e, p); setCurrentView('library'); } catch { alert("Wrong ID/Password"); }
  };
  return (
    <div className="max-w-sm mx-auto bg-white p-8 rounded-3xl shadow-2xl mt-10">
      <h2 className="text-2xl font-black text-center mb-6">LOGIN</h2>
      <form onSubmit={login} className="grid gap-4">
        <input type="email" placeholder="Email Address" className="p-4 bg-gray-50 rounded-xl outline-none focus:ring-2 ring-orange-500" onChange={x => setE(x.target.value)} />
        <input type="password" placeholder="Password" className="p-4 bg-gray-50 rounded-xl outline-none focus:ring-2 ring-orange-500" onChange={x => setP(x.target.value)} />
        <button className="bg-orange-600 text-white py-4 rounded-xl font-bold mt-2">Login to Library</button>
        <p className="text-center text-xs text-gray-500">New student? <span className="text-orange-600 font-bold cursor-pointer" onClick={() => setCurrentView('register')}>Create Account</span></p>
      </form>
    </div>
  );
}

function RegisterPage({ setCurrentView }) {
  const [form, setForm] = useState({ name: '', email: '', pass: '' });
  const reg = async (ev) => {
    ev.preventDefault();
    try {
      await createUserWithEmailAndPassword(auth, form.email, form.pass);
      alert("Account Created!"); setCurrentView('library');
    } catch (e) { alert(e.message); }
  };
  return (
    <div className="max-w-sm mx-auto bg-white p-8 rounded-3xl shadow-2xl mt-10">
      <h2 className="text-2xl font-black text-center mb-6">SIGN UP</h2>
      <form onSubmit={reg} className="grid gap-4">
        <input placeholder="Full Name" className="p-4 bg-gray-50 rounded-xl" onChange={x => setForm({...form, name: x.target.value})} />
        <input type="email" placeholder="Email Address" className="p-4 bg-gray-50 rounded-xl" onChange={x => setForm({...form, email: x.target.value})} />
        <input type="password" placeholder="Create Password" className="p-4 bg-gray-50 rounded-xl" onChange={x => setForm({...form, pass: x.target.value})} />
        <button className="bg-orange-600 text-white py-4 rounded-xl font-bold mt-2">Register Now</button>
      </form>
    </div>
  );
}

function MyBooksPage({ books, currentUser, purchases, setCurrentView }) {
  const approvedIds = purchases.filter(p => p.status === 'approved').map(p => p.bookId);
  const myBooks = books.filter(b => approvedIds.includes(b.id));

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">My Purchased Content</h2>
      {myBooks.length === 0 ? <p className="text-gray-400">No books owned yet.</p> : (
        <div className="grid md:grid-cols-3 gap-6">
          {myBooks.map(b => (
            <div key={b.id} className="bg-white p-6 rounded-2xl border-2 border-green-100 shadow-sm">
              <h3 className="font-bold mb-4">{b.title}</h3>
              <button onClick={() => setCurrentView(`view-${b.id}`)} className="w-full bg-green-600 text-white py-2 rounded-lg font-bold">Open Access</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function HomePage({ setCurrentView, currentUser }) {
  return (
    <div className="text-center py-20">
      <h2 className="text-5xl font-black text-orange-900 mb-4 tracking-tighter">SUCCESS STARTS HERE.</h2>
      <p className="text-xl text-orange-700 mb-8 opacity-80">Access Important Questions for PDSU Shekhawati University Exam 2024</p>
      {!currentUser && (
        <button onClick={() => setCurrentView('register')} className="bg-orange-600 text-white px-10 py-5 rounded-3xl font-black text-xl shadow-2xl shadow-orange-300 hover:scale-105 transition-transform">REGISTER & START STUDYING</button>
      )}
    </div>
  );
}

function BookViewer({ bookId, books, currentUser, purchases, setCurrentView }) {
  const book = books.find(b => b.id === bookId);
  const isApproved = purchases.some(p => p.bookId === bookId && p.status === 'approved');

  useEffect(() => {
    if (isApproved) {
      const lock = (e) => e.preventDefault();
      document.addEventListener('contextmenu', lock);
      return () => document.removeEventListener('contextmenu', lock);
    }
  }, [isApproved]);

  if (!isApproved) return <div className="text-center py-20 font-bold text-red-600">Access Restricted. Payment Not Verified.</div>;

  return (
    <div className="max-w-4xl mx-auto bg-white p-10 rounded-3xl shadow-2xl border-2 border-green-50">
      <button onClick={() => setCurrentView('my-books')} className="text-gray-400 mb-6 font-bold uppercase text-xs tracking-widest">← Back to My Library</button>
      <h2 className="text-3xl font-black mb-1 text-gray-800 uppercase">{book.title}</h2>
      <p className="text-xs font-bold text-green-600 mb-10 tracking-widest uppercase italic">Secure Reader Active • {currentUser.email}</p>
      
      <div className="prose max-w-none text-gray-700 leading-relaxed select-none" style={{ userSelect: 'none' }}>
        <div dangerouslySetInnerHTML={{ __html: book.content }} />
      </div>

      <div className="mt-20 p-6 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4">
        <Shield className="text-gray-300" size={32} />
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter leading-tight">
          Warning: Unauthorized sharing or screenshots will result in immediate account termination. Your IP and email are logged.
        </p>
      </div>
    </div>
  );
}
